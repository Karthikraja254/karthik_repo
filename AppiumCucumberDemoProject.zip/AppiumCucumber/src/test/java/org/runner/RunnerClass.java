package org.runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\HP\\eclipse-workspace\\NewWork\\AppiumCucumber\\src\\test\\resources\\FeatureFile.feature",
					glue = "org.steps",
					dryRun = true,
					plugin = {"pretty","json:C:\\Users\\HP\\eclipse-workspace\\NewWork\\AppiumCucumber\\Report\\jvmnewreport.json"},
					monochrome = true)
					
public class RunnerClass {
	
	@AfterClass
	public static void afterClass() {
		JVMReporting.generateReporting("C:\\Users\\HP\\eclipse-workspace\\NewWork\\AppiumCucumber\\Report\\jvmnewreport.json");
	}

}
