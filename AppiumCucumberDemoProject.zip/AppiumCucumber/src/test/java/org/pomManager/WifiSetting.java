package org.pomManager;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.utilityPackage.BaseClass;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class WifiSetting extends BaseClass{
	
	public WifiSetting() {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(className = "android.widget.CheckBox")
	private WebElement checkBox;
	
	public WebElement getCheckBox() {
		return checkBox;
	}

	public void setCheckBox(WebElement checkBox) {
		this.checkBox = checkBox;
	}

	public WebElement getWifiOption() {
		return wifiOption;
	}

	public void setWifiOption(WebElement wifiOption) {
		this.wifiOption = wifiOption;
	}

	public WebElement getTextBox() {
		return textBox;
	}

	public void setTextBox(WebElement textBox) {
		this.textBox = textBox;
	}

	public WebElement getOkButton() {
		return okButton;
	}

	public void setOkButton(WebElement okButton) {
		this.okButton = okButton;
	}

	@AndroidFindBy(xpath = "//android.widget.ListView[@resource-id=\\\"android:id/list\\\"]/android.widget.LinearLayout[2]/android.widget.RelativeLayout")
	private WebElement wifiOption;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id=\\\"android:id/edit\\\"]")
	private WebElement textBox;
	
	@AndroidFindBy(className = "android:id/button1")
	private WebElement okButton;
	
	@AndroidFindBy(accessibility = "message")
	private WebElement msg;

	public WebElement getMsg() {
		return msg;
	}

	public void setMsg(WebElement msg) {
		this.msg = msg;
	}
	

}
