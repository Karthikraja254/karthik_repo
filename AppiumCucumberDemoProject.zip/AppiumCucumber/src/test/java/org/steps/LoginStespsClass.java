package org.steps;



import java.util.List;

import org.openqa.selenium.By;
import org.pomManager.HomePagePojoClass;
import org.pomManager.PreferancePage;
import org.pomManager.WifiSetting;
import org.utilityPackage.BaseClass;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import junit.framework.Assert;

public class LoginStespsClass extends BaseClass{
	
	AppiumDriverLocalService service;
	WifiSetting w;
	
	@Given("I have launch the application")
	public void i_have_launch_the_application() {
		service = buildAppiumService();
		service.start();
	}
	@When("I have selected {string} and clicked {string}")
	public void i_have_selected_and_clicked(String string, String string2) {
		HomePagePojoClass hp = new HomePagePojoClass();
		hp.getPreferance().click();
		
	}
	@When("I have click the check button and enterd the {string}")
	public void i_have_click_the_check_button_and_enterd_the(String string) {
		
		PreferancePage pp = new PreferancePage();
		pp.getPreferenceDependencies().click();
		w = new WifiSetting();
		w.getCheckBox().click();
		w.getWifiOption().click();
		w.getTextBox().sendKeys("vignesh wifi");
		w.getOkButton().click();
		
	}
	@Then("the name should be accepted")
	public void the_name_should_be_accepted() {
	    Assert.assertEquals(w.getMsg().getText(), "wifi added");
	}
	
}
